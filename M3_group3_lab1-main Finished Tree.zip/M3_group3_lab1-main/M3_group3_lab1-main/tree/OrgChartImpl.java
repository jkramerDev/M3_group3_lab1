package tree;
import java.util.LinkedList;
import java.util.Queue;
public class OrgChartImpl implements OrgChart{
	private GenericTreeNode<Employee> root;
	@Override
	public void addRoot(Employee e){
		if(root == null){
			root = new GenericTreeNode<>(e);
		}
		else{
			System.out.println("The root already exists");
		}
	}
	@Override
	public void clear(){
		root = null;
	}
	@Override
	public void addDirectReport(Employee manager, Employee newPerson){
		GenericTreeNode<Employee> managerNode = findNode(root, manager);
		if(managerNode != null){
			GenericTreeNode<Employee> newPersonNode = new GenericTreeNode<>(newPerson);
			managerNode.addChild(newPersonNode);
		}
		else{
			System.out.println("Manager was not found");
		}
	}
	@Override
	public void removeEmployee(Employee firedPerson){
		GenericTreeNode<Employee> nodeToRemove = findNode(root, firedPerson);
		if(nodeToRemove != null){
			GenericTreeNode<Employee> parent = findParent(root, firedPerson);
			if(parent != null){
				int index = parent.children.indexOf(nodeToRemove);
				for(GenericTreeNode<Employee> child : nodeToRemove.children){
					parent.children.add(index++, child);
				}
				parent.children.remove(nodeToRemove);
				nodeToRemove = null;
			}
			else if(nodeToRemove == root){
				clear();
			}
		}
		else{
			System.out.println("Employee not found.");
		}
	}
	@Override
	public void showOrgChartDepthFirst(){
		depthFirstTraversal(root);
		System.out.println("- - - ");
		System.out.println();
	}
	@Override
	public void showOrgChartBreadthFirst(){
		breadthFirstTraversal(root);
		System.out.println("- - - ");
		System.out.println();
	}
	private GenericTreeNode<Employee> findNode(GenericTreeNode<Employee> node, Employee employee){
		if(node == null){
			return null;
		}
		if(node.data.equals(employee)){
			return node;
		}
		for(GenericTreeNode<Employee> child : node.children){
			GenericTreeNode<Employee> result = findNode(child, employee);
			if(result != null){
				return result;
			}
		}
		return null;
	}
	private GenericTreeNode<Employee> findParent(GenericTreeNode<Employee> node, Employee employee){
		if(node == null || node.children.isEmpty()){
			return null;
		}
		for(GenericTreeNode<Employee> child : node.children){
			if(child.data.equals(employee)){
				return node;
			}
			GenericTreeNode<Employee> parent = findParent(child, employee);
			if(parent != null){
				return parent;
			}
		}
		return null;
	}
	private void depthFirstTraversal(GenericTreeNode<Employee> node){
		if(node == null){
			return;
		}
		System.out.println(node.data);
		for(GenericTreeNode<Employee> child : node.children){
			depthFirstTraversal(child);
		}
	}
	private void breadthFirstTraversal(GenericTreeNode<Employee> node){
		Queue<GenericTreeNode<Employee>> queue = new LinkedList<>();
		queue.add(node);
		while(!queue.isEmpty()){
			GenericTreeNode<Employee> current = queue.poll();
			System.out.println(current.data);
			for(GenericTreeNode<Employee> child : current.children){
				queue.add(child);
			}
		}
	}
}
